package com.sung.hee.help;

/**
 * Created by SungHere on 2017-05-10.
 */
//com.sung.hee.help.BoardCheck
public class BoardCheck {
    @Override
    public String toString() {
        return "BoardCheck{" +
                "type=" + type +
                ", seq=" + seq +
                '}';
    }

    public BoardCheck() {
    }

    private int type = 0;

    private int seq = 0;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getSeq() {
        return seq;
    }

    public void setSeq(int seq) {
        this.seq = seq;
    }
}
