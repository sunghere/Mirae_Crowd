CREATE PROCEDURE stu_id_check_proc(
  p_stu_id IN  student.stu_id%TYPE,
  p_result OUT NUMBER
) IS
  chk NUMBER := 0;

  BEGIN
    SELECT count(*)
    INTO chk
    FROM student
    WHERE p_stu_id = stu_id;

    IF chk = 0
    THEN -- 없을경우
      p_result := 1;
    ELSE -- 있을경우
      p_result := 0;

    END IF;


  END;
/
