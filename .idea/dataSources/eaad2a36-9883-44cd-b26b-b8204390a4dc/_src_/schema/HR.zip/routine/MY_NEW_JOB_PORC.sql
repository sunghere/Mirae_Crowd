CREATE PROCEDURE my_new_job_porc(
  stu_id    IN student.stu_id%TYPE,
  name      IN student.name%TYPE,
  tel       IN student.tel%TYPE,
  birth     IN student.birth%TYPE,
  dept_code IN student.dept_code%TYPE
)
IS


  BEGIN
    INSERT INTO student VALUES (stu_id, name, tel, birth, dept_code);
  END;
/
