CREATE PROCEDURE proc_student(

  p_stu_id    IN student.stu_id%TYPE,
  cur_student OUT SYS_REFCURSOR
) IS



  BEGIN

    OPEN cur_student FOR SELECT
                           stu_id,
                           name,
                           tel,
                           birth
                         FROM student
                         WHERE stu_id = p_stu_id;


    END;
/
