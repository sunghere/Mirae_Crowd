CREATE PROCEDURE proc_search_stu(

  selector    IN NUMBER,
  p_search    IN NVARCHAR2,
  cur_student OUT SYS_REFCURSOR
) IS

  BEGIN
    IF selector = 1 --이름검색
    THEN
      OPEN cur_student FOR

      SELECT
        stu_id,
        name,
        tel,
        birth,
        d.dept_name dept

      FROM student s, dept d
      WHERE s.dept_code = d.dept_code AND p_search = s.name;

    ELSIF selector = 2
      THEN --학과명검색
        OPEN cur_student FOR
        SELECT
          stu_id,
          name,
          tel,
          birth,
          d.dept_name dept
        FROM student s, dept d
        WHERE s.dept_code = d.dept_code AND p_search = d.dept_name;


    END IF;

  END;
/
