CREATE PROCEDURE my_new_job_proc(
  p_stu_id    IN student.stu_id%TYPE,
  p_name      IN student.name%TYPE,
  p_tel       IN student.tel%TYPE,
  p_birth     IN student.birth%TYPE,
  p_dept_code IN student.dept_code%TYPE
)
IS
  chk NUMBER := 0;

  BEGIN
    SELECT count(*)
    INTO chk
    FROM student
    WHERE p_stu_id = stu_id;
    IF chk = 0
    THEN
      INSERT INTO student VALUES (p_stu_id, p_name, p_tel, p_birth, p_dept_code);
    ELSE
      UPDATE student
      SET stu_id = p_stu_id, name = p_name, birth = p_birth, dept_code = p_dept_code
      WHERE p_stu_id = stu_id;

    END IF;
  END;
/
